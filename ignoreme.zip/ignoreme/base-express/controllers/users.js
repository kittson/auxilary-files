var express = require('express')
  , router = express.Router()

// Define routes handling profile requests

module.exports = router